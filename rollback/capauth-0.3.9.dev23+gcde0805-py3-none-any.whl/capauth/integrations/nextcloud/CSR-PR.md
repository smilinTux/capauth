# Certificate-request PR — ready to submit

> **Regenerated 2026-07-04** — the 2026-06-22 keypair was lost (never stored); this is a fresh RSA-4096 keypair + CSR. The old signed cert (PR #1054) is dead and has been removed from the repo. Private key is now stored in KeePass (`Work / CapAuth — Nextcloud App Store code-signing key`).

Submit this to <https://github.com/nextcloud/app-certificate-requests>.
**Requires Chef's GitHub account (with a public email set on the profile).**

## File to create in the PR

Path (in the `app-certificate-requests` repo): **`capauth/capauth.csr`**

Contents (paste exactly — this is `certificates/capauth.csr`):

```
-----BEGIN CERTIFICATE REQUEST-----
MIIEVzCCAj8CAQAwEjEQMA4GA1UEAwwHY2FwYXV0aDCCAiIwDQYJKoZIhvcNAQEB
BQADggIPADCCAgoCggIBAJMkK9LW9DgwJzcwicJrtRO4+LSq+6b/QxQ6cBUsgFI7
1okpD2FiBW58RKIU3O8oBvTqECoj0+UVViWy9jsARElXuf+pf7E77WSt0W9tk9sx
diWd1JHbPqbaoLL9/URSTgHTF/OZ9zinyFg1A9QHgQJfpLz64aBys9PP0JajU6bY
k7PddpYnldVJ4cwGzkJNNkDiMbo70KoUKHvVvs1PK1G1GkCJaE5HCiDxc/XbSvTt
UehRWgqSC2UPJjuCHnZgfs4TwgdBlB9OiK/crNMpmLx1hDIQ8sUe1tBylOWnUn0L
yAsP6WVHflaSo+WXzZ6unP6UpJQadpsboa5AR0b2l1++ndBmBxBINUnumu+3gIpv
Zr1poDm5wYChdLHzjTGwkyfBZf3cCuw+XC7lliLPfGA1un6BFzG8uVpTTenJ2phq
Q57jKFMOpPWTTrqH+RiyfY8o9gFfzBXNNsRT0dh5qhEfSCRY7CtmOoXcI2hgCim3
q5nQBPrWuxxsDcXoGR3XociZf13nKE0Zz4dbtpf7IsBJx1DFdJ45tPDnk5j81NP0
aKNkj/36wSzf2FhVLu53mu84mFcFWU0+zejLWuBRf2uF3Hnx15gezOYjUBqaSxyL
6lAUqxEeg7cKlyNcyutGKOEsk7u3H+9VVv1BGw9GkSdT5D6vEHTkStge9KfmGuw/
AgMBAAGgADANBgkqhkiG9w0BAQsFAAOCAgEAfJG+u4QtSvpSPFhUw0ku7LBw/8tP
QL9GecieFJ0y9Y4YXma02vBR3Z1ZwfP5S6LeSzLMaIOfQzgXwb8jKGOLVMrMeijv
Nb5Xli19gmCD23z2tdjoXQxOKUlpb8PepwqYVmRyp3/the6LzECIl+1g8wlrvNvq
BTPFIX9TdLBYng3jZ6X0vBmaM5EhQX7ttYCF1Nedm5Wz5PT3OQ6o0Z5GQkhc3cJ4
H6FubNcjhaeL7Hs9wweWreHNtspWUgFNlPkIILgsnmk0X40tV0FM6iLoHolvFaTA
y8m3um+YDf9mceEnQr0OiJBHjUCkkUyRMZU/KwZ2QFPlvy4mMzk2mbYBH/qSjEaB
1KXPWEFjiC796AvWsVp3s63vwMTkNqMKKLorAsYQczJT+GeAyCJEDSHLboWW849t
BnySqBahDC0xHbQfRNgGkUEjPRXE2ziqfj6+Dp8eh0Odwa0Vahc2UqdVe+J5yFDF
HKh8mLmnio0t9ATN15nZ+3gTG+psW/DWNM0r+bOYSRwh1TLs2xEbazyeYU1Henp8
5e7+pd5iRy4sGsNpEDcg8ARoNG8YYoPqGowoMXq5fP5X++vUfD9ipxKbQGhDp/ot
Pp1acRVrV0deTXUgWE92hMJPHS6SB+DXEavytwGvShMNHo0zOfsw7cyRmbdRO7yb
NIGcJ4gr5VqxENs=
-----END CERTIFICATE REQUEST-----
```

> The CSR's Common Name is `CN=capauth` — verified to equal the app id, which
> is the hard requirement. Do **not** also add the `.crt`; Nextcloud creates it.

## PR title

```
Add certificate for capauth
```

## PR body

```
Certificate request for the CapAuth app (app id: capauth).

Passwordless PGP primary-login user backend for Nextcloud.
Source: https://github.com/smilintux/capauth
```

## After merge

Nextcloud issues `capauth.crt`. Save it to **both**:
- `~/.nextcloud/certificates/capauth.crt` (for krankerl / local signing), and
- `certificates/capauth.crt` in this repo (commit it — the .crt is public).

See `PUBLISHING.md` steps 1c–1d.
