"""
CapAuth P2P Mesh — serverless peer discovery and identity verification.

Two discovery modes:
  - LOCAL: mDNS/UDP broadcast on the LAN (zero config, instant)
  - GLOBAL: Nostr relay announcements for cross-network discovery

Peers announce their PGP fingerprint and listening address. Other
peers discover them, then run CapAuth challenge-response directly
over TCP sockets — no server, no API, no middleman.

The mesh operates independently of Syncthing/SKComm. It's the raw
identity layer: "I am who I say I am, and I can prove it."
"""

from __future__ import annotations

import json
import logging
import secrets
import socket
import struct
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

from pydantic import BaseModel, Field

logger = logging.getLogger("capauth.mesh")

MESH_PORT = 5297
MDNS_GROUP = "224.0.0.251"
MDNS_PORT = 5298
ANNOUNCE_INTERVAL = 30
PEER_TTL = 120

SERVICE_TAG = "capauth-mesh-v1"


class PeerInfo(BaseModel):
    """A discovered peer on the mesh."""

    fingerprint: str = Field(description="PGP fingerprint (40 hex chars)")
    name: str = Field(default="", description="Display name")
    host: str = Field(description="IP address or hostname")
    port: int = Field(default=MESH_PORT, description="Listening port")
    last_seen: float = Field(
        default_factory=time.time, description="Unix timestamp of last announcement"
    )
    source: str = Field(default="mdns", description="How we discovered this peer")

    @property
    def is_alive(self) -> bool:
        """Check if this peer's announcement is still fresh."""
        return (time.time() - self.last_seen) < PEER_TTL

    @property
    def address(self) -> str:
        """Return host:port string."""
        return f"{self.host}:{self.port}"


class MeshAnnouncement(BaseModel):
    """The payload broadcast during peer discovery."""

    service: str = SERVICE_TAG
    fingerprint: str
    name: str = ""
    port: int = MESH_PORT
    timestamp: float = Field(default_factory=time.time)


class ChallengeOverWire(BaseModel):
    """Challenge-response messages exchanged over TCP."""

    action: str = Field(description="challenge, response, or result")
    challenge_hex: str = ""
    signature: str = ""
    fingerprint: str = ""
    verified: Optional[bool] = None


class PeerRegistry:
    """Thread-safe registry of discovered peers.

    Peers are added via mDNS or Nostr announcements and expire
    after PEER_TTL seconds without a refresh.

    Args:
        on_peer_discovered: Optional callback fired when a new peer appears.
    """

    def __init__(
        self, on_peer_discovered: Optional[Callable[[PeerInfo], None]] = None
    ) -> None:
        self._peers: dict[str, PeerInfo] = {}
        self._lock = threading.Lock()
        self._callback = on_peer_discovered

    def upsert(self, peer: PeerInfo) -> bool:
        """Add or update a peer. Returns True if this is a new peer.

        Args:
            peer: The peer info to register.

        Returns:
            True if the peer was not previously known.
        """
        with self._lock:
            is_new = peer.fingerprint not in self._peers
            self._peers[peer.fingerprint] = peer
            if is_new and self._callback:
                self._callback(peer)
            return is_new

    def get(self, fingerprint: str) -> Optional[PeerInfo]:
        """Look up a peer by fingerprint.

        Args:
            fingerprint: PGP fingerprint to look up.

        Returns:
            PeerInfo or None if not found or expired.
        """
        with self._lock:
            peer = self._peers.get(fingerprint)
            if peer and peer.is_alive:
                return peer
            return None

    def alive_peers(self) -> list[PeerInfo]:
        """Return all peers whose announcements are still fresh.

        Returns:
            List of alive PeerInfo objects.
        """
        with self._lock:
            return [p for p in self._peers.values() if p.is_alive]

    def remove(self, fingerprint: str) -> None:
        """Remove a peer from the registry.

        Args:
            fingerprint: PGP fingerprint to remove.
        """
        with self._lock:
            self._peers.pop(fingerprint, None)

    def gc(self) -> int:
        """Remove expired peers. Returns count removed.

        Returns:
            Number of peers garbage collected.
        """
        with self._lock:
            expired = [fp for fp, p in self._peers.items() if not p.is_alive]
            for fp in expired:
                del self._peers[fp]
            return len(expired)


def create_announcement(fingerprint: str, name: str = "", port: int = MESH_PORT) -> bytes:
    """Serialize a mesh announcement for broadcast.

    Args:
        fingerprint: This agent's PGP fingerprint.
        name: Display name.
        port: Listening port for challenge-response.

    Returns:
        UTF-8 JSON bytes ready to send over UDP.
    """
    ann = MeshAnnouncement(fingerprint=fingerprint, name=name, port=port)
    return ann.model_dump_json().encode("utf-8")


def parse_announcement(data: bytes, source_host: str) -> Optional[PeerInfo]:
    """Parse a received mesh announcement.

    Args:
        data: Raw UDP payload bytes.
        source_host: IP address the packet came from.

    Returns:
        PeerInfo if valid, None otherwise.
    """
    try:
        raw = json.loads(data.decode("utf-8"))
        if raw.get("service") != SERVICE_TAG:
            return None
        return PeerInfo(
            fingerprint=raw["fingerprint"],
            name=raw.get("name", ""),
            host=source_host,
            port=raw.get("port", MESH_PORT),
            last_seen=time.time(),
            source="mdns",
        )
    except (json.JSONDecodeError, KeyError, ValueError):
        return None


class MeshDiscovery:
    """mDNS-based local peer discovery.

    Broadcasts this agent's fingerprint on the LAN multicast group
    and listens for announcements from other agents.

    Args:
        fingerprint: This agent's PGP fingerprint.
        name: Display name for announcements.
        registry: Peer registry to update on discovery.
        port: Mesh listening port.
    """

    def __init__(
        self,
        fingerprint: str,
        name: str = "",
        registry: Optional[PeerRegistry] = None,
        port: int = MESH_PORT,
    ) -> None:
        self.fingerprint = fingerprint
        self.name = name
        self.port = port
        self.registry = registry or PeerRegistry()
        self._running = False
        self._threads: list[threading.Thread] = []

    def start(self) -> None:
        """Start discovery: begin announcing and listening."""
        if self._running:
            return
        self._running = True

        listen_thread = threading.Thread(
            target=self._listen_loop, daemon=True, name="mesh-listen"
        )
        announce_thread = threading.Thread(
            target=self._announce_loop, daemon=True, name="mesh-announce"
        )
        self._threads = [listen_thread, announce_thread]
        listen_thread.start()
        announce_thread.start()
        logger.info("Mesh discovery started for %s on port %d", self.fingerprint[:16], self.port)

    def stop(self) -> None:
        """Stop discovery threads."""
        self._running = False
        logger.info("Mesh discovery stopped")

    @property
    def is_running(self) -> bool:
        """Check if discovery is active."""
        return self._running

    def announce_once(self) -> bool:
        """Send a single multicast announcement.

        Returns:
            True if the announcement was sent successfully.
        """
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            payload = create_announcement(self.fingerprint, self.name, self.port)
            sock.sendto(payload, (MDNS_GROUP, MDNS_PORT))
            sock.close()
            return True
        except OSError as exc:
            logger.debug("Announce failed: %s", exc)
            return False

    def _announce_loop(self) -> None:
        """Periodically broadcast our presence."""
        while self._running:
            self.announce_once()
            time.sleep(ANNOUNCE_INTERVAL)

    def _listen_loop(self) -> None:
        """Listen for multicast peer announcements."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("", MDNS_PORT))

            mreq = struct.pack(
                "4sl", socket.inet_aton(MDNS_GROUP), socket.INADDR_ANY
            )
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
            sock.settimeout(2.0)

            while self._running:
                try:
                    data, (host, _port) = sock.recvfrom(4096)
                    peer = parse_announcement(data, host)
                    if peer and peer.fingerprint != self.fingerprint:
                        is_new = self.registry.upsert(peer)
                        if is_new:
                            logger.info("Discovered peer: %s @ %s", peer.name or peer.fingerprint[:16], peer.address)
                except socket.timeout:
                    self.registry.gc()
        except OSError as exc:
            logger.error("Listen failed: %s", exc)


def challenge_peer(
    peer: PeerInfo,
    my_fingerprint: str,
    timeout: float = 5.0,
) -> Optional[ChallengeOverWire]:
    """Run a challenge-response verification against a peer over TCP.

    Connects to the peer, sends a random challenge, and expects a
    signed response. Does NOT verify the signature -- the caller
    should use capauth.identity.verify_challenge for that.

    Args:
        peer: The peer to challenge.
        my_fingerprint: Our PGP fingerprint (the challenger).
        timeout: Socket timeout in seconds.

    Returns:
        ChallengeOverWire with the peer's response, or None on failure.
    """
    challenge_hex = secrets.token_hex(32)

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((peer.host, peer.port))

        msg = ChallengeOverWire(
            action="challenge",
            challenge_hex=challenge_hex,
            fingerprint=my_fingerprint,
        )
        sock.sendall(msg.model_dump_json().encode("utf-8") + b"\n")

        response_data = b""
        while b"\n" not in response_data:
            chunk = sock.recv(4096)
            if not chunk:
                break
            response_data += chunk

        sock.close()

        if not response_data:
            return None

        raw = json.loads(response_data.strip())
        return ChallengeOverWire(**raw)

    except (OSError, json.JSONDecodeError, ValueError) as exc:
        logger.debug("Challenge to %s failed: %s", peer.address, exc)
        return None


class MeshResponder:
    """TCP server that responds to incoming challenge-response requests.

    When a peer connects and sends a challenge, this responder
    calls the provided sign_func to produce a signature, then
    sends back the response.

    Args:
        fingerprint: This agent's PGP fingerprint.
        sign_func: Callable that signs bytes and returns a signature string.
        port: TCP port to listen on.
    """

    def __init__(
        self,
        fingerprint: str,
        sign_func: Callable[[bytes], str],
        port: int = MESH_PORT,
    ) -> None:
        self.fingerprint = fingerprint
        self._sign_func = sign_func
        self.port = port
        self._running = False
        self._server_socket: Optional[socket.socket] = None

    def start(self) -> None:
        """Start listening for incoming challenges."""
        if self._running:
            return
        self._running = True
        thread = threading.Thread(
            target=self._serve_loop, daemon=True, name="mesh-responder"
        )
        thread.start()
        logger.info("Mesh responder listening on port %d", self.port)

    def stop(self) -> None:
        """Stop the responder."""
        self._running = False
        if self._server_socket:
            try:
                self._server_socket.close()
            except OSError:
                pass

    def _serve_loop(self) -> None:
        """Accept connections and handle challenges."""
        try:
            self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_socket.bind(("0.0.0.0", self.port))
            self._server_socket.listen(5)
            self._server_socket.settimeout(2.0)

            while self._running:
                try:
                    conn, addr = self._server_socket.accept()
                    threading.Thread(
                        target=self._handle_connection,
                        args=(conn, addr),
                        daemon=True,
                    ).start()
                except socket.timeout:
                    continue
        except OSError as exc:
            logger.error("Responder bind failed: %s", exc)

    def _handle_connection(self, conn: socket.socket, addr: tuple) -> None:
        """Handle a single incoming challenge."""
        try:
            conn.settimeout(5.0)
            data = b""
            while b"\n" not in data:
                chunk = conn.recv(4096)
                if not chunk:
                    break
                data += chunk

            if not data:
                conn.close()
                return

            raw = json.loads(data.strip())
            msg = ChallengeOverWire(**raw)

            if msg.action != "challenge":
                conn.close()
                return

            signature = self._sign_func(msg.challenge_hex.encode("utf-8"))

            response = ChallengeOverWire(
                action="response",
                challenge_hex=msg.challenge_hex,
                signature=signature,
                fingerprint=self.fingerprint,
            )
            conn.sendall(response.model_dump_json().encode("utf-8") + b"\n")
            conn.close()

        except Exception as exc:
            logger.debug("Handle connection from %s failed: %s", addr, exc)
            try:
                conn.close()
            except OSError:
                pass
