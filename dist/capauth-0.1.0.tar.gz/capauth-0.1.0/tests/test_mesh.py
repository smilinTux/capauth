"""Tests for the CapAuth P2P mesh networking module.

Covers peer registry, announcements, mDNS parsing, TCP
challenge-response, and the mesh discovery/responder lifecycle.
"""

from __future__ import annotations

import json
import socket
import threading
import time
from unittest.mock import MagicMock

import pytest

from capauth.mesh import (
    MESH_PORT,
    SERVICE_TAG,
    ChallengeOverWire,
    MeshAnnouncement,
    MeshDiscovery,
    MeshResponder,
    PeerInfo,
    PeerRegistry,
    challenge_peer,
    create_announcement,
    parse_announcement,
)


# ═══════════════════════════════════════════════════════════
# PeerInfo model
# ═══════════════════════════════════════════════════════════


class TestPeerInfo:
    """Test the PeerInfo model."""

    def test_is_alive_fresh(self):
        """Recently seen peer is alive."""
        peer = PeerInfo(fingerprint="A" * 40, host="192.168.1.10")
        assert peer.is_alive is True

    def test_is_alive_expired(self):
        """Stale peer is not alive."""
        peer = PeerInfo(
            fingerprint="A" * 40,
            host="192.168.1.10",
            last_seen=time.time() - 300,
        )
        assert peer.is_alive is False

    def test_address_format(self):
        """address property returns host:port."""
        peer = PeerInfo(fingerprint="B" * 40, host="10.0.0.1", port=5297)
        assert peer.address == "10.0.0.1:5297"


# ═══════════════════════════════════════════════════════════
# PeerRegistry
# ═══════════════════════════════════════════════════════════


class TestPeerRegistry:
    """Test the thread-safe peer registry."""

    def test_upsert_new_peer(self):
        """Adding a new peer returns True."""
        reg = PeerRegistry()
        peer = PeerInfo(fingerprint="A" * 40, host="10.0.0.1")
        assert reg.upsert(peer) is True

    def test_upsert_existing_peer(self):
        """Updating an existing peer returns False."""
        reg = PeerRegistry()
        peer = PeerInfo(fingerprint="A" * 40, host="10.0.0.1")
        reg.upsert(peer)
        assert reg.upsert(peer) is False

    def test_get_found(self):
        """Look up an existing peer by fingerprint."""
        reg = PeerRegistry()
        peer = PeerInfo(fingerprint="C" * 40, host="10.0.0.2")
        reg.upsert(peer)
        found = reg.get("C" * 40)
        assert found is not None
        assert found.host == "10.0.0.2"

    def test_get_not_found(self):
        """Look up a nonexistent peer returns None."""
        reg = PeerRegistry()
        assert reg.get("D" * 40) is None

    def test_get_expired_returns_none(self):
        """Expired peer is not returned by get()."""
        reg = PeerRegistry()
        peer = PeerInfo(fingerprint="E" * 40, host="10.0.0.3", last_seen=time.time() - 300)
        reg.upsert(peer)
        assert reg.get("E" * 40) is None

    def test_alive_peers(self):
        """alive_peers returns only fresh peers."""
        reg = PeerRegistry()
        alive = PeerInfo(fingerprint="F" * 40, host="10.0.0.4")
        dead = PeerInfo(fingerprint="G" * 40, host="10.0.0.5", last_seen=time.time() - 300)
        reg.upsert(alive)
        reg.upsert(dead)
        assert len(reg.alive_peers()) == 1

    def test_remove(self):
        """remove() deletes a peer."""
        reg = PeerRegistry()
        peer = PeerInfo(fingerprint="H" * 40, host="10.0.0.6")
        reg.upsert(peer)
        reg.remove("H" * 40)
        assert reg.get("H" * 40) is None

    def test_gc_removes_expired(self):
        """gc() cleans up stale peers."""
        reg = PeerRegistry()
        reg.upsert(PeerInfo(fingerprint="I" * 40, host="10.0.0.7"))
        reg.upsert(PeerInfo(fingerprint="J" * 40, host="10.0.0.8", last_seen=time.time() - 300))
        removed = reg.gc()
        assert removed == 1
        assert len(reg.alive_peers()) == 1

    def test_callback_on_new_peer(self):
        """on_peer_discovered callback fires for new peers only."""
        callback = MagicMock()
        reg = PeerRegistry(on_peer_discovered=callback)
        peer = PeerInfo(fingerprint="K" * 40, host="10.0.0.9")
        reg.upsert(peer)
        reg.upsert(peer)
        assert callback.call_count == 1


# ═══════════════════════════════════════════════════════════
# Announcements
# ═══════════════════════════════════════════════════════════


class TestAnnouncements:
    """Test announcement creation and parsing."""

    def test_create_announcement(self):
        """create_announcement produces valid JSON bytes."""
        data = create_announcement("A" * 40, "Jarvis", 5297)
        parsed = json.loads(data)
        assert parsed["service"] == SERVICE_TAG
        assert parsed["fingerprint"] == "A" * 40
        assert parsed["name"] == "Jarvis"
        assert parsed["port"] == 5297

    def test_parse_announcement_valid(self):
        """parse_announcement creates PeerInfo from valid data."""
        data = create_announcement("B" * 40, "Lumina")
        peer = parse_announcement(data, "192.168.1.100")
        assert peer is not None
        assert peer.fingerprint == "B" * 40
        assert peer.host == "192.168.1.100"
        assert peer.name == "Lumina"

    def test_parse_announcement_wrong_service(self):
        """Announcements with wrong service tag are rejected."""
        data = json.dumps({"service": "wrong", "fingerprint": "C" * 40}).encode()
        assert parse_announcement(data, "10.0.0.1") is None

    def test_parse_announcement_invalid_json(self):
        """Invalid JSON is rejected."""
        assert parse_announcement(b"not json", "10.0.0.1") is None

    def test_parse_announcement_missing_fingerprint(self):
        """Missing fingerprint field is rejected."""
        data = json.dumps({"service": SERVICE_TAG}).encode()
        assert parse_announcement(data, "10.0.0.1") is None


# ═══════════════════════════════════════════════════════════
# TCP challenge-response
# ═══════════════════════════════════════════════════════════


class TestChallengeResponse:
    """Test TCP-based challenge-response between peers."""

    def test_responder_and_challenger(self):
        """Full lifecycle: responder starts, challenger connects."""
        test_port = 15297

        def mock_sign(data: bytes) -> str:
            return "mock-signature-" + data.hex()[:16]

        responder = MeshResponder(
            fingerprint="R" * 40,
            sign_func=mock_sign,
            port=test_port,
        )
        responder.start()
        time.sleep(0.3)

        try:
            peer = PeerInfo(fingerprint="R" * 40, host="127.0.0.1", port=test_port)
            result = challenge_peer(peer, "C" * 40, timeout=3.0)

            assert result is not None
            assert result.action == "response"
            assert result.fingerprint == "R" * 40
            assert result.signature.startswith("mock-signature-")
            assert result.challenge_hex != ""
        finally:
            responder.stop()

    def test_challenge_peer_unreachable(self):
        """Challenging an unreachable peer returns None."""
        peer = PeerInfo(fingerprint="X" * 40, host="127.0.0.1", port=19999)
        result = challenge_peer(peer, "Y" * 40, timeout=0.5)
        assert result is None


# ═══════════════════════════════════════════════════════════
# ChallengeOverWire model
# ═══════════════════════════════════════════════════════════


class TestChallengeOverWire:
    """Test the wire-format challenge model."""

    def test_challenge_serialization(self):
        """ChallengeOverWire roundtrips through JSON."""
        msg = ChallengeOverWire(
            action="challenge",
            challenge_hex="abcd1234",
            fingerprint="Z" * 40,
        )
        data = msg.model_dump_json()
        parsed = ChallengeOverWire.model_validate_json(data)
        assert parsed.action == "challenge"
        assert parsed.challenge_hex == "abcd1234"

    def test_response_includes_signature(self):
        """Response messages carry a signature."""
        msg = ChallengeOverWire(
            action="response",
            challenge_hex="beef",
            signature="sig-data",
            fingerprint="W" * 40,
        )
        assert msg.signature == "sig-data"


# ═══════════════════════════════════════════════════════════
# MeshDiscovery lifecycle
# ═══════════════════════════════════════════════════════════


class TestMeshDiscovery:
    """Test the MeshDiscovery class lifecycle."""

    def test_start_stop(self):
        """Discovery starts and stops cleanly."""
        registry = PeerRegistry()
        discovery = MeshDiscovery(
            fingerprint="M" * 40,
            name="test-agent",
            registry=registry,
        )
        assert discovery.is_running is False
        discovery.start()
        assert discovery.is_running is True
        time.sleep(0.2)
        discovery.stop()
        assert discovery.is_running is False

    def test_announce_once(self):
        """Single announcement doesn't raise."""
        discovery = MeshDiscovery(fingerprint="N" * 40)
        # May fail in CI without multicast support, that's OK
        discovery.announce_once()
